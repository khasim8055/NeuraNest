﻿# -*- mode: python ; coding: utf-8 -*-
block_cipher = None
a = Analysis(['main.py'],pathex=[],binaries=[],datas=[('app/schema.sql','app'),('app/data','app/data'),('app/assets','app/assets')],hiddenimports=['PyQt6','PyQt6.QtWidgets','PyQt6.QtCore','PyQt6.QtGui','PyQt6.sip','matplotlib','matplotlib.backends.backend_qtagg','matplotlib.figure','matplotlib.patches','matplotlib.pyplot','numpy','numpy.core','numpy.core._multiarray_umath','numpy.core.multiarray','reportlab','reportlab.lib','reportlab.lib.pagesizes','reportlab.lib.units','reportlab.lib.styles','reportlab.lib.colors','reportlab.lib.enums','reportlab.platypus','cryptography','cryptography.fernet','bcrypt','sqlalchemy','sqlite3','csv','pathlib','datetime','collections','platform','subprocess'],hookspath=[],runtime_hooks=[],excludes=['streamlit','tkinter'],cipher=block_cipher)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(pyz,a.scripts,[],exclude_binaries=True,name='NeuraCare',debug=False,strip=False,upx=True,console=False)
coll = COLLECT(exe,a.binaries,a.zipfiles,a.datas,strip=False,upx=True,name='NeuraCare')
